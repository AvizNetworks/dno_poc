# HBN BF3 Bringup Scripts

Automated scripts to bring up NVIDIA HBN (Host-Based Networking) on a BlueField-3 DPU running DOCA 3.3.0.

**Validated on:** `bf-bundle-3.3.0-202_26.01_ubuntu-24.04_64k_prod.bfb`

---

## What is HBN?

HBN turns the BF3 DPU into a virtual switch and router between:
- **Your x86 host** (connected via PCIe)
- **The Top-of-Rack switch** (connected via physical ports p0/p1)

The BF3 runs OVS-DPDK for hardware-offloaded switching and FRR for routing (BGP, OSPF, static routes, BFD). You configure routing on 4 interfaces inside the `doca-hbn` container — not on the host.

```
ToR Switch ←──── p0_if / p1_if          (configure routing here)
x86 Host   ←──── pf0hpf_if / pf1hpf_if  (configure routing here)
```

---

## Quick Start

### Step 0 — Flash the BF3 with the validated BFB (skip if already running it)

Check what the BF3 is running: `ssh ubuntu@<BF3-OOB-IP> cat /etc/mlnx-release`.
If it already shows `bf-bundle-3.3.0-202_26.01_ubuntu-24.04_64k_prod`, skip to Step 1.

> **The BFB is NOT included in this package** — it is NVIDIA software, downloaded
> under your own DOCA license (NVIDIA DOCA downloads → BlueField BFB bundles).
> This release is validated against exactly this build — verify the checksum:
> ```
> file:   bf-bundle-3.3.0-202_26.01_ubuntu-24.04_64k_prod.bfb   (~1.5 GB)
> sha256: f74e8a5cf8a1628094b5e77a6d9a7eae47fe15b11e5a9e64e125c7369906d8af
> ```

Flash from the **x86 host** the BF3 is installed in, over the PCIe rshim interface:

```bash
# on the x86 host
sudo apt install rshim                 # if not already installed
ls /dev/rshim0/boot                    # rshim device must be present
sha256sum bf-bundle-3.3.0-202_26.01_ubuntu-24.04_64k_prod.bfb   # must match above

sudo bfb-install --bfb bf-bundle-3.3.0-202_26.01_ubuntu-24.04_64k_prod.bfb --rshim rshim0
# (equivalent low-level form: sudo bash -c 'cat <file>.bfb > /dev/rshim0/boot')
```

The flash takes ~10–15 minutes and the BF3 reboots itself when done. Notes:

- **Push stalls / "Connection timed out"** → the BF3's own BMC may be running a
  competing rshim — on the BMC: `systemctl stop rshim`. Also bump the timeout:
  `echo "BOOT_TIMEOUT 1200" | sudo tee /dev/rshim0/misc`.
- **First login** — connect to the BF3 console (`sudo minicom -D /dev/rshim0/console`
  or via the BMC) and set the `ubuntu` user password when prompted.
- **After the flash, reboot the x86 host** if its BF3 PF netdevs don't reappear —
  reflashing under a running host can stale the host's PCIe link to the DPU.
- SSH says `REMOTE HOST IDENTIFICATION HAS CHANGED` afterwards → expected (new
  host key): `ssh-keygen -R <BF3-OOB-IP>`.

### Step 1 — Clone the repo to the BF3

```bash
scp -r /path/to/hbn/ ubuntu@<BF3-OOB-IP>:~/hbn/
ssh ubuntu@<BF3-OOB-IP>
cd ~/hbn
```

The repo must be present in full — `scripts/bringup_hbn_bf3.sh` deploys configs from `mellanox/` and `doca_hbn_v3.3.0/` at the repo root.

### Step 2 — Preflight (read-only; run until it says READY)

```bash
sudo ./scripts/bringup_hbn_bf3.sh --check
```

Validates **every** prerequisite without changing anything — platform, repo files,
link type (IB vs ETH), switchdev mode, **eswitch multiport firmware
(`LAG_RESOURCE_ALLOCATION` — see note below)**, sfc payload, udev namers, runtime
units, container image (offline-first), hugepages, VF eswitch reps (with `--vfs`) —
and prints the exact fix for each failure. Exit 0 = ready. Optionally preview the
full 15-step plan with `--dry-run`. A normal run refuses to start while blockers exist.

> **Multiport note (important for p1):** all HBN SubFunctions live on PF0, so
> traffic on the **p1** uplink requires eswitch multiport, gated on firmware
> `LAG_RESOURCE_ALLOCATION=1`. That nvconfig only truly applies on a **cold power
> cycle of the x86 host** (`sudo ipmitool chassis power cycle`) — an ARM reboot is
> NOT enough, and a live-set value showing `1` can be cosmetic. The preflight
> checks the real *Current* value and tells you exactly what to do.

### Step 3 — Run bringup on BF3

```bash
sudo ./scripts/bringup_hbn_bf3.sh
```

With BGP enabled and a custom REST API password:
```bash
sudo ./scripts/bringup_hbn_bf3.sh --enable-bgp --rest-pass MyPass123
```

Fully offline — no internet access is needed (use `--skip-dns-fix` to leave
resolv.conf untouched on air-gapped sites). Idempotent — safe to re-run anytime.

### Step 4 — Check status

```bash
sudo ./scripts/status_hbn.sh
```

### Step 5 — View interface reference

```bash
sudo ./scripts/topology_hbn.sh
```

### Step 6 — Start configuring FRR

```bash
CONT=$(sudo crictl ps | grep doca-hbn | grep -v init | awk '{print $1}')
sudo crictl exec -it $CONT vtysh
```

---

## Repository Layout

```
hbn/
├── scripts/          # runnable scripts (copy full repo to BF3)
├── docs/             # reference docs and runbooks
├── mellanox/         # reference config files deployed by bringup
└── doca_hbn_v3.3.0/  # official NVIDIA HBN package (scripts + pod spec)
```

---

## Scripts

### `scripts/bringup_hbn_bf3.sh`

**Run on BF3 with sudo. Idempotent — safe to re-run.**

**Preflight-first**: every prerequisite is validated read-only (with an exact fix
printed per failure) before anything is changed; a run refuses to start on blockers.
Then 15 idempotent steps (0–14):

0. Host prep, fully offline (register sfc.service, patch udev SF namers, CNI conflist — `install.sh` is deliberately NOT run)
1. Verify eswitch switchdev mode + **enable eswitch multiport** (mlnx-bf.conf + devlink runtime — required for the p1 uplink)
2. Fix DNS (optional, `--skip-dns-fix` for air-gapped sites)
3. Create required hostPath directories
4. Generate `hbn.conf`, `sfc.conf`, `mlnx-sf.conf` dynamically (VF-aware)
5. Allocate hugepages (1600×2MB) and create persistent service
6. Provision SubFunctions (sfnum 2, 3, 1514, 1515 + VF sfnums 1001+/1257+ if `--vfs` set)
7. OVS health check — stale-ofport recovery (clean br-hbn rebuild, never per-port edits)
8. Validate OVS ports on `br-hbn`
9. Verify `doca_hbn` container image (offline-first; import instructions if missing)
10. Wait for `doca-hbn` pod Running (init-sfs deadlock auto-recovery)
11. Bring up all interfaces inside the container
12. Enable BGP in FRR (optional)
13. Configure REST API — password persisted across container restarts, listen on 0.0.0.0
14. **Passive datapath validation** — wire-RX vs container-RX counters per uplink (catches the eswitch-multiport unicast blackhole that config-plane checks cannot see)

**Options:**

| Flag | Default | Description |
|---|---|---|
| `--check` | — | Preflight only, read-only; exit 0 = ready. Nothing is changed |
| `--dry-run` | — | Preflight + print the full step plan; nothing is changed |
| `--enable-bgp` | off | Enable bgpd in FRR daemons |
| `--rest-user <user>` | `nvidia` | REST API username |
| `--rest-pass <pass>` | `nvidia` | REST API password |
| `--skip-dns-fix` | off | Skip adding nameserver 8.8.8.8 |
| `--vfs <n>` | 0 | Total VFs split equally across both PFs (e.g. `--vfs 8` → 4 per PF) |
| `--p0-vfs <n>` | 0 | VFs on PF0 only |
| `--p1-vfs <n>` | 0 | VFs on PF1 only |

**VF prerequisite** — enable SR-IOV on the x86 host before running with `--vfs`:
```bash
# On x86 host (run once, make persistent via udev or systemd)
echo 4 > /sys/class/net/enp65s0f0np0/device/sriov_numvfs
echo 4 > /sys/class/net/enp65s0f1np1/device/sriov_numvfs
```
Or use the helper, which auto-detects the BF3 PFs, creates 4 VFs/PF, and installs
a systemd unit so they persist across reboot:
```bash
# on the x86 host, from this repo's scripts/
sudo ./scripts/setup_host_vfs_standalone.sh
```

---

### `scripts/topology_hbn.sh`

**Run on BF3 with sudo.**

Prints the 4 configurable interfaces with their live state, MAC, and IP. Saves output to `/var/log/doca/hbn/topology-<timestamp>.txt`.

Example output:
```
  [1] ToR Uplink 0       → connects to Top-of-Rack switch port 0
      FRR Interface : p0_if
      MAC           : 5c:25:73:79:c8:9c
      IP Address    : (not configured)
      Link State    : UP
```

---

### `scripts/status_hbn.sh`

**Run on BF3 with sudo.**

Runs a full health check across all HBN components and reports `[OK]` / `[WARN]` / `[FAIL]`:

- eswitch switchdev mode
- SubFunctions (sfnum 2, 3, 1514, 1515)
- `doca-hbn` container running
- SF representors (`p0_if_r`, `p1_if_r`, `pf0hpf_if_r`, `pf1hpf_if_r`)
- OVS bridge `br-hbn` — port errors, offloaded flow count
- FRR daemons (zebra, bgpd, bfdd)
- Interface states inside container
- NVUE REST API reachability

---

### `scripts/access_hbn.sh`

**Run from any machine.**

Prints all access methods for the BF3. Accepts `--bf3-ip <IP>` to override the default IP.

```bash
./access_hbn.sh --bf3-ip <BF3-OOB-IP>
```

---

### `scripts/mirror_to_dpu.sh`

**Run on the x86 host with sudo.**

Sets up a tc mirred copy from the host's internet-facing interface to the BF3 PCIe link. Traffic is copied (not redirected) so existing connectivity is completely unaffected. The copy flows through OVS `br-hbn` and can be mirrored to `aviz0` for Aviz Service Node (ASN) DPI.

```bash
sudo ./scripts/mirror_to_dpu.sh start    # enable mirror
sudo ./scripts/mirror_to_dpu.sh stop     # remove mirror, restore default qdisc
sudo ./scripts/mirror_to_dpu.sh status   # show current state
```

Edit `SRC_IFACE` and `DST_IFACE` at the top of the script for your server. Defaults are for S1: `eno2 → enp65s0f0np0`.

---

## Configuring Routing (Post-Bringup)

All routing is configured inside the `doca-hbn` container. The BF3 hardware offloads the dataplane automatically.

### Get a shell

```bash
CONT=$(sudo crictl ps | grep doca-hbn | grep -v init | awk '{print $1}')
sudo crictl exec -it $CONT vtysh
```

### Assign IPs to interfaces

```
conf t
interface p0_if
 ip address 192.168.1.1/30
 no shutdown
!
interface pf0hpf_if
 ip address 10.10.0.1/24
 no shutdown
```

### Configure BGP

```
router bgp 65000
 neighbor 192.168.1.2 remote-as 65001
 address-family ipv4 unicast
  network 10.10.0.0/24
 exit-address-family
```

### Via REST API

```bash
# Get system info
curl -k -u nvidia:nvidia https://<BF3-OOB-IP>:8765/nvue_v1/system

# Get all interfaces
curl -k -u nvidia:nvidia https://<BF3-OOB-IP>:8765/nvue_v1/interface
```

---

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| Pod not starting, kubelet errors | Missing `/var/lib/hbn/` dirs | Run `bringup_hbn_bf3.sh` |
| `aa-complain: not found` in init-sfs logs | `apparmor-utils` missing | `sudo apt install apparmor-utils` |
| `p0_if` not found in container | SFs not provisioned | `sudo bash /etc/mellanox/mlnx-sf.conf` |
| OVS ports show "No such device" | SF representors not created | Provision SFs, then restart OVS |
| `crictl pull` fails / DNS error | `/etc/resolv.conf` missing public DNS | `echo "nameserver 8.8.8.8" >> /etc/resolv.conf` |
| REST API returns 401 | Default credentials not set up | Run `hbn-dpu-setup.sh -u nvidia -p nvidia -e` from its source dir |
| bgpd not running | Disabled by default | `--enable-bgp` flag or edit `/var/lib/hbn/etc/frr/daemons` |
| Interfaces DOWN after pod start | Netns move leaves them DOWN | `ip link set p0_if up` inside container |
| BGP on **p1** stuck `Active`/`Connect`, ping fails, links all UP | Eswitch multiport off — firmware `LAG_RESOURCE_ALLOCATION` ≠ 1 (p1 can't reach the PF0-hosted SFs) | `--check` gates this; stage `mlxconfig -d 0000:03:00.0 set LAG_RESOURCE_ALLOCATION=1` (both PFs), then **cold power cycle the x86 host** (`ipmitool chassis power cycle`). ARM reboot is NOT enough |
| REST API works, then breaks after container restart / power cycle (401) | REST user was created live but never persisted | Re-run bringup — step 13 persists it via `hbn-users` (survives restarts) |

---

## Architecture Reference

For deep-dive architecture, config file annotations, and the full manual procedure see:
[docs/bf3-hbn-bringup.md](docs/bf3-hbn-bringup.md)
